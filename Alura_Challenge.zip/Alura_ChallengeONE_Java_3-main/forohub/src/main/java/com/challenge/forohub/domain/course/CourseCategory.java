package com.challenge.forohub.domain.course;

public enum CourseCategory {
    TECHNOLOGY,
    GENERAL,
    HARDWARE,
    SOFTWARE
}
