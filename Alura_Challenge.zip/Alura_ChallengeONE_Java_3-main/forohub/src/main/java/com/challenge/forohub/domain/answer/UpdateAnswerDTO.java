package com.challenge.forohub.domain.answer;

public record UpdateAnswerDTO(
        String message,
        String solution
) {
}
