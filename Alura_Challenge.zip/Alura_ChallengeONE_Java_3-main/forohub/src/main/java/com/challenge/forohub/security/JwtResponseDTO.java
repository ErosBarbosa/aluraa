package com.challenge.forohub.security;

public record JwtResponseDTO(
        String jwt
) {
}
